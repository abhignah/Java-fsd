package com.ecommerce.controller;

public @interface Autowired {

}
