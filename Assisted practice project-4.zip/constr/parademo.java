package constr;

public class parademo {
    public static void main(String[] args) {
		
		Std sts1=new Std(7,"ram");
		Std std2=new Std(5,"ajay");
		sts1.display();
		std2.display();
    }
}
	
