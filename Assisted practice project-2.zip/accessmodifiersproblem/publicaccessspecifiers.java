package accessmodifiersproblem;

public class publicaccessspecifiers {
	//2. using private access specifiers
			class priaccessspecifier 
			{ 
			   private void display() 
			    { 
			        System.out.println("You are using private access specifier"); 
			    } 
			} 

}
