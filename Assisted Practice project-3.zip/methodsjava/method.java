package methodsjava;
		public class method{
			public int multiplynumbers(int a,int b) {
				int z=a*b;
				return z;
			}
			public static void main(String[]args) {
				method b=new method();
				int ans=b.multiplynumbers(10,3);
				System.out.println("Multiplication is :"+ans);
			}
		}
		
		
		



