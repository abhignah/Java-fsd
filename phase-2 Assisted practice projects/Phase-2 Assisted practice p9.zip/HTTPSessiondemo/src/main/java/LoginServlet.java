import java.io.*;

import org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException;
import org.ietf.jgss.GSSException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSessionContext;
import jakarta.servlet.http.HttpSessionIdListener;



/**
* Servlet implementation class LoginServlet
*/
public class LoginServlet extends HttpServlet {
        private static final long serialVersionUID = 1L;
       
    /**
* @see HttpServlet#HttpServlet()
*/
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

        /**
         * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
         */
        protected void doGet(HttpServlet request, HttpServletResponse response) throws ClassFormatException, IOException {
                // TODO Auto-generated method stub
                
                 String userId = request.getInitParameter("userid");
                 @SuppressWarnings("deprecation")
				HttpSessionIdListener session=((Object) request).getSession();  
             ((Object) session).setAttribute("userid",  userId);
                          
             response.sendRedirect("dashboard");  
                
        }

        /**
         * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
         */
        protected void doPost(HttpServletResponse request, HttpServletResponse response) throws GSSException, IOException {
                // TODO Auto-generated method stub
                doPost(request, response);
        }

}


